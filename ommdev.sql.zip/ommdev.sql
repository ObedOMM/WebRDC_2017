-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le: Sam 17 Juin 2017 à 09:17
-- Version du serveur: 5.5.24-log
-- Version de PHP: 5.4.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `ommdev`
--

-- --------------------------------------------------------

--
-- Structure de la table `commentaires`
--

CREATE TABLE IF NOT EXISTS `commentaires` (
  `id_commentaire` int(11) NOT NULL AUTO_INCREMENT,
  `commentaire` text NOT NULL,
  `utilisateur` varchar(255) NOT NULL,
  `id_utilisateur` int(7) NOT NULL,
  `id_conseil` int(11) NOT NULL,
  `date_creation` datetime NOT NULL,
  PRIMARY KEY (`id_commentaire`),
  KEY `date_creation` (`date_creation`),
  KEY `id_conseil` (`id_conseil`),
  KEY `id_utilisateur` (`id_utilisateur`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Contenu de la table `commentaires`
--

INSERT INTO `commentaires` (`id_commentaire`, `commentaire`, `utilisateur`, `id_utilisateur`, `id_conseil`, `date_creation`) VALUES
(1, 'mblkmlkmlkmllmkmlkml\nbmlkmlkmlkmlklmkmlkml \nklllllllllllllllllllllll \nllllllllll \nllllllllllllllmmmm \nmmmmmmmmmmm \nmmmmmmmmmkkkkkk \nkkkkkkkkkkkkkkkkk \nkkkkkkkkkkkkkkkkkkkkkkkkkkkkk', 'kibawa', 2, 1, '2017-04-27 10:30:53'),
(2, 'Bo kosi| beu?', 'obed', 1, 2, '2017-04-27 00:00:00'),
(3, 'Ahhhhhhh ba yaya bo tika ba buzoba kooo oyo eza site ya ba bétises té!\r\nto zala mikolo!', 'obed', 1, 1, '2017-05-01 20:50:00'),
(4, 'yeah! Si vous continuez, on aura juste qu''à apppliquer les reglements!\r\nVous blocquer dans ce forum sera la meilleur chose à nfaire!\r\nMerçi pour votre comprehension!', 'Obed', 1, 1, '2017-05-02 10:07:10'),
(5, 'yeah! Si vous continuez, on aura juste qu''à apppliquer les reglements!\r\nVous blocquer dans ce forum sera la meilleur chose à nfaire!\r\nMerçi pour votre comprehension!', 'Obed', 1, 1, '2017-05-02 10:07:23'),
(6, 'Salut tout le monde!\r\nAujourd''hui nous allons parler de la musique avec jean pierre de RonSany!!!', 'Sharon', 2, 1, '2017-05-02 10:11:43'),
(7, 'A vous tous membre de la OMMDev je vous souhaite les bienvenues!', 'Belar', 1, 1, '2017-05-02 10:13:34'),
(8, 'A vous tous membre de la OMMDev je vous souhaite les bienvenues!', 'Belar', 1, 1, '2017-05-02 10:15:29'),
(9, 'Vous vous permettez de dire qu''ils sont des reveur tandis que vous êtes vous les véritables rêveurs du monde entier!...', 'Kzubanata', 2, 3, '2017-05-02 10:23:56'),
(10, 'Vous vous permettez de dire qu''ils sont des reveur tandis que vous êtes vous les véritables rêveurs du monde entier!...', 'Kzubanata', 1, 3, '2017-05-02 10:26:37'),
(11, 'Hum!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!', 'Galilée', 2, 3, '2017-05-02 10:37:39'),
(12, 'Hum!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!', 'Galilée', 2, 3, '2017-05-02 10:40:36'),
(13, 'Euh!!!!!!!!!!!!!!!', 'Galilée', 2, 3, '2017-05-02 10:43:12'),
(14, 'Ah oyo vraiment ékomi ko lékisa! Eza donc vraiment pasi', '', 1, 4, '2017-05-21 09:04:00'),
(15, 'yOOOOOOOOOOO Me voiçi de retour!!!!!', 'oBED', 1, 3, '2017-05-02 10:47:16'),
(16, 'kkkkk!', 'BInos', 1, 3, '2017-05-02 10:49:24'),
(17, 'Bonjour!', 'omm5050', 1, 5, '2017-05-21 08:42:13'),
(18, 'Ajourd''hui nous allons parler sur la programmation orientée objet!', 'omm5050', 1, 5, '2017-05-21 08:42:51'),
(19, 'Me voiçi avec mes toutes nouvelles façons de concevoir un site internet ;', 'omm5050', 1, 5, '2017-05-21 08:44:41'),
(20, 'Pona nini buzoba ya niveau oyo?', 'omm5050', 1, 1, '2017-05-21 09:04:29');

-- --------------------------------------------------------

--
-- Structure de la table `jaime`
--

CREATE TABLE IF NOT EXISTS `jaime` (
  `id_jaime` int(7) NOT NULL AUTO_INCREMENT,
  `id_conseil` int(7) NOT NULL,
  `nom_user_inscrit` varchar(25) NOT NULL,
  PRIMARY KEY (`id_jaime`),
  KEY `id_conseil` (`id_conseil`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Contenu de la table `jaime`
--

INSERT INTO `jaime` (`id_jaime`, `id_conseil`, `nom_user_inscrit`) VALUES
(1, 1, 'omm5050'),
(2, 1, 'Gali01'),
(3, 6, 'omm5050'),
(4, 7, 'omm5050'),
(5, 4, 'omm5050'),
(6, 5, 'omm5050'),
(7, 3, 'omm5050'),
(8, 2, 'omm5050');

-- --------------------------------------------------------

--
-- Structure de la table `news_cool`
--

CREATE TABLE IF NOT EXISTS `news_cool` (
  `id_ncool` int(11) NOT NULL AUTO_INCREMENT,
  `titre_ncool` varchar(50) NOT NULL,
  `contenu_ncool` text NOT NULL,
  `categorie_ncool` char(15) NOT NULL,
  `nom_photo` varchar(255) NOT NULL,
  `extension_photo` char(5) NOT NULL,
  `description_ncool` char(25) NOT NULL,
  `date_creation_ncool` datetime NOT NULL,
  PRIMARY KEY (`id_ncool`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Contenu de la table `news_cool`
--

INSERT INTO `news_cool` (`id_ncool`, `titre_ncool`, `contenu_ncool`, `categorie_ncool`, `nom_photo`, `extension_photo`, `description_ncool`, `date_creation_ncool`) VALUES
(1, 'La Femme oiseau', 'rte etre tret retr eteytr ytyu tuyt utyu ', 'Linafoot', 'tuanzebe-190x122', 'jpg', 'mur de l''école', '2017-06-06 19:33:42'),
(2, 'La Femme oiseau', 'rte etre tret retr eteytr ytyu tuyt utyu ', 'Linafoot', 'tuanzebe-190x122', 'jpg', 'mur de l''école', '2017-06-06 19:33:42'),
(3, 'La Femme oiseau', 'rte etre tret retr eteytr ytyu tuyt utyu ', 'Linafoot', 'tuanzebe-190x122', 'jpg', 'mur de l''école', '2017-06-06 19:33:42'),
(4, 'L''ocean noir', 'rte etre tret retr eteytr ytyu tuyt utyu ', 'Afrique', 'tuanzebe-190x122', 'jpg', 'rte etre tret retr eteytr', '2017-06-06 19:13:42'),
(5, 'uyt uyttuyt ', 'ut uytuyt uyt yt yt yutuyt yutuy t yutuy tu ytytyut ytuytuy t ytt uytuyt', 'Afrique', '1998073-41956947-2560-1440', 'png', 'iuytu yiu', '2017-05-22 13:44:55'),
(6, 'hfhgfh', 'hgjhjfgjf jh kjhkj hhkj hkjhj hkj hjkhjhk hk hkj jh kjhkjhkjh jh khjh jhkj', 'Rdcongo', 'sATDEDE', 'jpg', 'cvbfhhbnh', '2017-05-22 20:21:00'),
(7, 'uyt uytut', ' iuyi uyiuy iyuy uy uyuyiy uyu yiuyiu yi uyiuyiu yi uy uyiuy iuyiuy uy iuyuiyui y u yuy uyiu yuy iuyuiy uyuy yu yuyiyuyi yuyuy uyuyiy uyuyuy uyu yuyu uyiu iuiou', 'Monde', '2410', 'jpg', 'iouyi ouuo i', '2017-05-22 13:37:02'),
(8, 'tet ctct t', 'rte etre tret retr eteytr ytyu tuyt utyu ', 'Rdcongo', 'lionel-messi-ballon-dor-adidas-barcelona3398649', 'jpg', 'rez', '2017-05-21 16:50:17'),
(9, 'tet ctct t', 'rte etre tret retr eteytr ytyu tuyt utyu ', 'Rdcongo', 'lionel-messi-ballon-dor-adidas-barcelona3398649', 'jpg', 'rez', '2017-05-21 16:50:17'),
(10, 'tet ctct t', 'rte etre tret retr eteytr ytyu tuyt utyu ', 'Rdcongo', 'lionel-messi-ballon-dor-adidas-barcelona3398649', 'jpg', 'rez', '2017-05-21 16:50:17');

-- --------------------------------------------------------

--
-- Structure de la table `news_simple`
--

CREATE TABLE IF NOT EXISTS `news_simple` (
  `id_nsimple` int(11) NOT NULL AUTO_INCREMENT,
  `titre_nsimple` varchar(70) NOT NULL,
  `contenu_nsimple` text NOT NULL,
  `categorie_nsimple` char(10) NOT NULL,
  `date_creation_ns` datetime NOT NULL,
  PRIMARY KEY (`id_nsimple`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Contenu de la table `news_simple`
--

INSERT INTO `news_simple` (`id_nsimple`, `titre_nsimple`, `contenu_nsimple`, `categorie_nsimple`, `date_creation_ns`) VALUES
(1, 'AS V. Club dans le groupe C', 'La confédération africaine de football (CAF) a procédé ce mercredi 26 avril au Caire en Egypte au tirage au sort de ces deux compétitions interclubs. Pour la première fois, la phase de poule...', 'Afrique', '2017-05-23 20:51:00'),
(2, 'COUPE DU CONGO – Site Kindu : Première réunion du ', 'Il s’est tenu ce samedi 20 mai 2017 au siège de la ligue de football du Maniema, la première réunion d’organisation de la phase des…', 'Linafoot', '2017-05-23 20:53:55'),
(3, 'Mazembe bat le CF Mounana 2-0', 'Le TP Mazembe a battu le Centre Formation Mounana du Gabon sur le score de 2-0, dimanche 14 mai 2017 au stade TP Mazembe, en match comptant pour la première journée de phases des groupes de la coupe des Confédérations de la CAF. Les corbeaux ont ouvert la marque par l’intermédiaire de Trésor Mputu à la 14éme minute, et Rashfore Kalaba a clôturé la marque à la 64éme minute...', 'Linafoot', '2017-05-23 21:00:22'),
(4, 'Mbokani renonce à l''équipe nationale de la RD Cong', 'L''attaquant du club anglais de Norwich, Dieumerci Mbokani (30 ans) a décidé de ne plus jouer avec l''équipe nationale de la République démocratique du Congo...', 'Rdcongo', '2017-05-23 21:03:16'),
(5, 'fttttt nnnn cccccccc', 'ttttttttttttt ttttttttttttt vvvvvv vvvvvvv dd ssssç ttttttttttttt vvvvvv vvvvvvv dd ssssç ttttttttttttt vvvvvv vvvvvvv dd ssssç  vvvvvvv dd ssssç ttttttttttttt vvvvvv vvvvvvv dd ssssç ', 'Afrique', '2017-06-06 20:31:03');

-- --------------------------------------------------------

--
-- Structure de la table `sujets`
--

CREATE TABLE IF NOT EXISTS `sujets` (
  `id_conseil` int(11) NOT NULL AUTO_INCREMENT,
  `titre_conseil` varchar(255) NOT NULL,
  `contenu_conseil` text NOT NULL,
  `id_utilisateur` int(7) NOT NULL,
  `date_cconseil` datetime NOT NULL,
  PRIMARY KEY (`id_conseil`),
  KEY `titre_conseil` (`titre_conseil`),
  KEY `id_utilisateur` (`id_utilisateur`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Contenu de la table `sujets`
--

INSERT INTO `sujets` (`id_conseil`, `titre_conseil`, `contenu_conseil`, `id_utilisateur`, `date_cconseil`) VALUES
(1, 'Comment parvenir à traquer', 'Un monsieur va acheter un kaka', 1, '0000-00-00 00:00:00'),
(2, 'Dix choses à connaitre avant de venir en RDC', 'La RDC, pays où coule du lait et du miel est un pays où les gens deviennent riche du jour au lendemain.\nVoulez-vous la connaitre? c''est simple!\n\n1) Vous devez mettre à coeur que les congolais sont gentils et plein de compension pour les inconnue\n\n2) Savoir être prudent et sage \n\n3) Bien viser ses objectif avant de venir s''installer\n\n4) Etre en garde contre\n\n5) Savoir bien organiser son temps\n\n6) Veuiller à bien se renseigner sur lieu que vous allez être logé', 2, '0000-00-00 00:00:00'),
(3, 'Pourquoi les congolais sont pauvres?', 'Les gens disent qu''ils sont en générale des reveurs!', 1, '0000-00-00 00:00:00'),
(4, 'Top 10 des écoles les plus discipliné à kinshasa', '', 1, '0000-00-00 00:00:00'),
(5, 'Comment passer inapersu dans un milieu compliqué?', 'Tout d''abord, il vous faudra etre d''une calme extreme et ne pas\n s''en meler dans des débat inutile et vaines; ensuite vous ne devrez surtout pas...', 2, '2017-04-30 17:58:47'),
(6, 'Les 7 Prophéties de 1933 - William Branham', '', 1, '2017-05-01 21:09:48'),
(7, 'Un bon matin je vais parler fraise', 'Pourquoi des pain? Je voudrais de la moutarde et du pain au lait', 2, '2017-05-04 00:06:52');

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs`
--

CREATE TABLE IF NOT EXISTS `utilisateurs` (
  `id_utilisateur` int(11) NOT NULL AUTO_INCREMENT,
  `pseudo_utilisateur` varchar(25) NOT NULL,
  `prenom_utilisateur` varchar(25) NOT NULL,
  `nom_utilisateur` varchar(25) NOT NULL,
  `sexe_utilisateur` char(1) NOT NULL,
  `mot_de_passe_utilisateur` varchar(16) NOT NULL,
  `email_utilisateur` varchar(255) NOT NULL,
  `date_de_naissance` date NOT NULL,
  `date_insc_utilisateur` datetime NOT NULL,
  PRIMARY KEY (`id_utilisateur`),
  UNIQUE KEY `pseudo_utilisateur` (`pseudo_utilisateur`),
  UNIQUE KEY `id_utilisateur` (`id_utilisateur`),
  UNIQUE KEY `pseudo_utilisateur_2` (`pseudo_utilisateur`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `utilisateurs`
--

INSERT INTO `utilisateurs` (`id_utilisateur`, `pseudo_utilisateur`, `prenom_utilisateur`, `nom_utilisateur`, `sexe_utilisateur`, `mot_de_passe_utilisateur`, `email_utilisateur`, `date_de_naissance`, `date_insc_utilisateur`) VALUES
(1, 'omm5050', 'Obed', 'Mulumba', 'M', 'Azertyuiop', 'ommartiste007@gmail.com', '1997-11-15', '2017-05-17 07:11:59'),
(2, 'Gali01', 'Galilee', 'Kibawa', 'M', 'gali!!', 'galileekibawa01@gmail.com', '1997-03-30', '2017-05-17 07:12:49');

-- --------------------------------------------------------

--
-- Structure de la table `videos_courte`
--

CREATE TABLE IF NOT EXISTS `videos_courte` (
  `id_video` int(7) NOT NULL AUTO_INCREMENT,
  `source_frame` varchar(255) NOT NULL,
  `nom_img_postage` varchar(255) NOT NULL,
  `ext_img_postage` char(5) NOT NULL,
  `categorie_video` char(10) NOT NULL,
  PRIMARY KEY (`id_video`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Contenu de la table `videos_courte`
--

INSERT INTO `videos_courte` (`id_video`, `source_frame`, `nom_img_postage`, `ext_img_postage`, `categorie_video`) VALUES
(1, 'www.youtube.com/embed/vZoJ5ZWnFeY', 'Christiano', 'jpg', 'Monde'),
(2, 'www.youtube.com/embed/vZoJ5ZWnFeY', 'blancoooo', 'jpg', 'Afrique'),
(3, 'www.youtube.com/embed/vZoJ5ZWnFeY', 'ibengeeee', 'jpg', 'Linafoot'),
(4, 'www.youtube.com/embed/vZoJ5ZWnFeY', 'tuanzebe-190x122', 'jpg', 'Rdcongo'),
(5, 'www.youtube.com/embed/vZoJ5ZWnFeY', 'lionel-messi-ballon-dor-adidas-barcelona3398649', 'jpg', 'Linafoot'),
(6, 'www.youtube.com/embed/vZoJ5ZWnFeY', 'lionel-messi-ballon-dor-adidas-barcelona3398649', 'jpg', 'Linafoot'),
(7, 'www.youtube.com/embed/vZoJ5ZWnFeY', 'tuanzebe-190x122', 'jpg', 'Rdcongo'),
(8, 'www.youtube.com/embed/vZoJ5ZWnFeY', 'ibengeeee', 'jpg', 'Linafoot'),
(9, 'www.youtube.com/embed/vZoJ5ZWnFeY', 'blancoooo', 'jpg', 'Afrique'),
(10, 'www.youtube.com/embed/vZoJ5ZWnFeY', 'Christiano', 'jpg', 'Monde'),
(11, 'www.youtube.com/embed/vZoJ5ZWnFeY', 'tuanzebe-190x122', 'jpg', 'Rdcongo');

-- --------------------------------------------------------

--
-- Structure de la table `videos_youtube`
--

CREATE TABLE IF NOT EXISTS `videos_youtube` (
  `id_video` int(7) NOT NULL AUTO_INCREMENT,
  `source_frame` varchar(255) NOT NULL,
  `photo_postage` varchar(255) NOT NULL,
  `extension` char(3) NOT NULL,
  PRIMARY KEY (`id_video`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Contenu de la table `videos_youtube`
--

INSERT INTO `videos_youtube` (`id_video`, `source_frame`, `photo_postage`, `extension`) VALUES
(1, 'www.youtube.com/embed/PhARrePxqCw', 'ibengeeee', 'jpg'),
(2, 'www.youtube.com/embed/PhARrePxqCw', 'ibengeeee', 'jpg'),
(3, 'www.youtube.com/embed/0sCIgNTlMco', 'blancoooo', 'jpg'),
(4, 'www.youtube.com/embed/qTpFI25tPJk', 'lllllllllll', 'png'),
(5, 'www.youtube.com/embed/vZoJ5ZWnFeY', 'dominikkumbela0', 'jpg'),
(6, 'www.youtube.com/embed/PhARrePxXXX', 'lionel-messi-ballon-dor-adidas-barcelona3398649', 'jpg'),
(7, 'www.youtube.com/embed/PhARrePxXXX', 'lionel-messi-ballon-dor-adidas-barcelona3398649', 'jpg'),
(8, 'www.youtube.com/embed/qTpFI25tPJk', 'lllllllllll', 'png'),
(9, 'www.youtube.com/embed/PhARrePxqCw', 'ibengeeee', 'jpg'),
(10, 'www.youtube.com/embed/PhARrePxXXX', 'lionel-messi-ballon-dor-adidas-barcelona3398649', 'jpg');

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `commentaires`
--
ALTER TABLE `commentaires`
  ADD CONSTRAINT `commentaires_ibfk_1` FOREIGN KEY (`id_conseil`) REFERENCES `sujets` (`id_conseil`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `commentaires_ibfk_2` FOREIGN KEY (`id_utilisateur`) REFERENCES `utilisateurs` (`id_utilisateur`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `jaime`
--
ALTER TABLE `jaime`
  ADD CONSTRAINT `jaime_ibfk_1` FOREIGN KEY (`id_conseil`) REFERENCES `sujets` (`id_conseil`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `sujets`
--
ALTER TABLE `sujets`
  ADD CONSTRAINT `sujets_ibfk_1` FOREIGN KEY (`id_utilisateur`) REFERENCES `utilisateurs` (`id_utilisateur`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
